#!/bin/bash -x
#service ssh restart

while (($#)); do
    case $1 in
        "--tb_port")
            shift
            TB_PORT=$1
            shift
            ;;
    esac
done

mkdir /model_dir
. /venv/visual_attribution/bin/activate && tensorboard --logdir /model_dir --port $TB_PORT --host 0.0.0.0
