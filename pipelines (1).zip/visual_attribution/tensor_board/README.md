# TensorBoard

[TensorBoard](https://www.tensorflow.org/tensorboard) is a part of
[TensorFlow](https://www.tensorflow.org/)
making model training more easier through visualization.
Using a TensorBoard web client you can
monitor model metrics, study model graphs
and do other useful jobs that can improve your model quality.

![Tensorboard](../docs/tensorboard.jpg)