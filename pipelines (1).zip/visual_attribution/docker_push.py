import os
import consts


def push_docker(dockerfile_path, img_uri):
    os.system(f'docker build -t {img_uri} -f {dockerfile_path} .')
    os.system(f'docker push {img_uri}')


if __name__ == '__main__':
    img_uris = [
        consts.TB_IMG_URI,
        consts.TRAINING_IMG_URI,
        consts.SVC_CREATION_IMG_URI,
        consts.WEB_APP_IMG_URI
    ]

    for img_uri in img_uris:
        dockerfile_path = img_uri.split('/')[-1].lstrip('va_').split(':')[0] + '/dockerfile'
        push_docker(dockerfile_path, img_uri)
