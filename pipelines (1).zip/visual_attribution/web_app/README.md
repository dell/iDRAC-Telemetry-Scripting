# Web App

To use the web app you just need to
choose an image you want to get a prediction for
and click on the submit button.
As soon as you do this, the web app will send the image
to the models served in the kubernetes cluster
and in a few seconds will print predictions
received from the models.

![Tensorboard](../docs/web_app.jpg)