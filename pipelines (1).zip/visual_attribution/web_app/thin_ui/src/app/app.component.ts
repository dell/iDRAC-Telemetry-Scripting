import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  reader = new FileReader();
  b64Image = null;

  url = '../predict';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  prediction=null;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.reader.onloadend = (e) => {
      this.b64Image = this.reader.result;
    }
  }

  onFileSelect(files) {
    if (files.length > 0) {
      this.reader.readAsDataURL(files[0]);
    }
  }

  onFileSubmit() {
    if (this.b64Image) {
      const b64Image = this.b64Image.split(',').slice(1).join(',');
      this.http.post(this.url, JSON.stringify(b64Image), this.httpOptions).subscribe((data) => {
        this.prediction = data;
      })
    }
  }
}
