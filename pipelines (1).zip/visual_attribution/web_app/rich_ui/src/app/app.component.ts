import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  reader = new FileReader();
  b64Image = null;

  initUrl = '../init-client';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  prediction='';
  servingUris=null;
  encodingDicts=null;

  constructor(private http: HttpClient) {}


  ngOnInit() {
    this.http.get(this.initUrl).subscribe((data) => {
      this.servingUris = data['servingUris'];
      this.encodingDicts = data['encodingDicts'];
    });
    this.reader.onloadend = (e) => {
      this.b64Image = this.reader.result;
    }
  }

  onFileSelect(files) {
    if (files.length > 0) {
      this.reader.readAsDataURL(files[0]);
    }
  }

  onFileSubmit() {
    if (this.b64Image) {
      const b64Image = this.b64Image.split(',').slice(1).join(',');

      this.prediction = '';
      let uriCnt = this.servingUris.length;

      for (let i = 0; i < uriCnt; i++) {
        let curUri = this.servingUris[i];
        let request = {"jsonData": {"instances": [{"image_bytes": {"b64": b64Image}}]}};
        this.http.post<any[]>(curUri, JSON.stringify(request), this.httpOptions).subscribe((data) => {
          let maxIndex = 0;
          data = data['jsonData']['predictions'][0] as any[];
          for (let j = 1; j < data.length; j++) {
            if (data[j] > data[maxIndex]) {
              maxIndex = j;
            }
          }
          this.prediction += this.encodingDicts[i][maxIndex] + ' ';
        })
      }
    }
  }
}
