import argparse
import json
import requests
from multiprocessing import Pool

from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--use_thin_client', type=int)
    parser.add_argument('--web_app_port', default='9210')
    parser.add_argument('--serving_uri', required=True)
    parser.add_argument('--model_name', required=True, nargs='+')
    args = parser.parse_args()

static_folder = 'thin_static' if args.use_thin_client else 'rich_static'
print(static_folder)
app = Flask(__name__, static_url_path='/static/', static_folder=static_folder)
CORS(app)


def build_body(b64_img):
    return {
        'instances': [
            {'image_bytes': {'b64': b64_img}}
        ]
    }


def decode_response(response, encoding_dict):
    prediction = json.loads(response.text)['predictions'][0]
    cls_idx = np.argmax(prediction)
    return encoding_dict[cls_idx]


def call_serving(args):
    b64_img, uri, encoding_dict = args
    body = build_body(b64_img)
    response = requests.post(uri, json=body)
    return decode_response(response, encoding_dict)


@app.route('/init-client', methods=['GET'])
def init_client():
    global serving_uris, encoding_dicts
    return jsonify({'servingUris': serving_uris, 'encodingDicts': encoding_dicts})


@app.route('/predict', methods=['POST'])
def get_prediction():
    global serving_uris, encoding_dicts
    b64_img = request.get_json()
    predictions = Pool(2).imap(call_serving, zip([b64_img] * len(serving_uris), serving_uris, encoding_dicts))
    return jsonify(' '.join(predictions))



@app.route('/')
def main_page():
    return app.send_static_file('index.html')


if __name__ == '__main__':
    serving_uris = []
    encoding_dicts = []

    for model_name in args.model_name:
        serving_uri = args.serving_uri.format(model_name=model_name)
        serving_uris.append(serving_uri)

        with open(f'/tmp/{model_name}.json', 'r') as f:
            encoding_dicts.append(json.load(f))

    args = parser.parse_args()
    app.run(host='0.0.0.0', port=args.web_app_port)
