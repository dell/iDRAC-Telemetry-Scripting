#!/bin/bash
. /venv/visual_attribution/bin/activate

ARGS=""
MODEL_NAME=()


while (($#)); do
    case $1 in
        "--model_name")
            shift
            while [[ $1 != --* ]] && (($#)); do
                MODEL_NAME+=($1)
                shift
            done
            ;;
        "--s3_endpoint")
            shift
            S3_ENDPOINT=$1
            shift
            ;;
        "--encoding_dir_uri")
            shift
            ENCODING_DIR_URI=$1
            shift
            ;;
        *)
            ARGS=$ARGS" "$1
            shift
            ;;
    esac
done

if [[ $ENCODING_DIR_URI == gs://* ]]; then
  echo $CREDS_JSON > /creds.json
  gcloud auth activate-service-account --key-file=/creds.json

  for ITEM in ${MODEL_NAME[*]}; do
      gsutil cp $ENCODING_DIR_URI""$ITEM".json" "/tmp/"$ITEM".json"
  done
else
  aws configure set default.s3.multipart_threshold 10GB
  for ITEM in ${MODEL_NAME[*]}; do
      aws --endpoint-url $S3_ENDPOINT s3 cp $ENCODING_DIR_URI""$ITEM".json" "/tmp/"$ITEM".json"
  done
fi

python3 /visual_attribution/web_app/main.py $ARGS --model_name ${MODEL_NAME[*]}
