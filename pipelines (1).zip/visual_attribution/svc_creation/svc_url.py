import argparse
import json
import time

import kubernetes


def get_svc_desc(k8s_api, namespace, svc_name, metadata, show_load_balancer):
    svc_ip = None
    sleep = 10
    timeout = 60
    while (not svc_ip) or (timeout <= 0):
        time.sleep(sleep)
        timeout -= sleep
        svc_desc = k8s_api.list_namespaced_service(namespace, field_selector=f'metadata.name={svc_name}').items[0]
        try:
            svc_ip = svc_desc.status.load_balancer.ingress[0].ip
        except:
            pass

    svc_port = svc_desc.spec.ports[0].port
    svc_uri = f'http://{svc_ip}:{svc_port}/'

    metadata['outputs'] += [
        {
            'type': 'markdown',
            'storage': 'inline',
            'source': f'[LoadBalancer URL]({svc_uri})'
        },
    ]
    print('LoadBalancer URL: ', svc_uri)


def expand_dict(dict_str):
    parts = dict_str.split('=')
    parts = [part.split() for part in parts]

    keys = [part[-1] for part in parts[:-1]]
    values = [part[:-1] for part in parts[1:-1]] + [parts[-1]]

    res = []
    for i in range(len(values[0])):
        res.append({})
        for j in range(len(keys)):
            key, value = keys[j], values[j][i]
            res[-1][key] = value

    return res


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--namespace', required=True)
    parser.add_argument('--svc_name', required=True)
    parser.add_argument('--fmt_args', nargs='+')
    parser.add_argument('--show_load_balancer', type=int)
    args = parser.parse_args()

    kubernetes.config.load_incluster_config()
    k8s_api = kubernetes.client.CoreV1Api()
    metadata = {'outputs': []}

    if args.fmt_args is None:
        get_svc_desc(k8s_api, args.namespace, args.svc_name, metadata, args.show_load_balancer)
    else:
        args_list = expand_dict(' '.join(args.fmt_args))
        for cur_args in args_list:
            cur_svc_name = args.svc_name.format(**cur_args)
            cur_namespace = args.namespace.format(**cur_args)
            get_svc_desc(k8s_api, cur_namespace, cur_svc_name, metadata, args.show_load_balancer)

    with open('/mlpipeline-ui-metadata.json', 'w') as f:
        json.dump(metadata, f)
