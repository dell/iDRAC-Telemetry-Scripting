import argparse
import base64
from urllib.parse import urlparse
from jinja2 import Template


def str_to_b64(s):
    return base64.b64encode(s.encode('utf-8')).decode('utf-8')


def gen_yaml(template, gen_args, yaml_f):
    render = template.render(**gen_args)
    print(render)
    yaml_f.write(render)
    yaml_f.writable()


def expand_dict(dict_str):
    parts = dict_str.split('=')
    parts = [part.split() for part in parts]

    keys = [part[-1] for part in parts[:-1]]
    values = [part[:-1] for part in parts[1:-1]] + [parts[-1]]

    res = []
    for i in range(len(values[0])):
        res.append({})
        for j in range(len(keys)):
            key, value = keys[j], values[j][i]
            res[-1][key] = value

    return res


def fmt_dict(cur_dict, fmt_args):
    cur_dict = cur_dict.copy()
    for k in cur_dict:
        if isinstance(cur_dict[k], str):
            cur_dict[k] = cur_dict[k].format(**fmt_args)
    return cur_dict


def to_gcp_frm(uri):
    return uri.replace('s3://', 'gs://')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--show_load_balancer', type=int)
    parser.add_argument('--fmt_args', nargs='+')

    parser.add_argument('--namespace')
    parser.add_argument('--service_account')

    parser.add_argument('--model_name')
    parser.add_argument('--model_uri')
    # parser.add_argument('--s3_endpoint')
    # parser.add_argument('--aws_access_key_id')
    # parser.add_argument('--aws_secret_access_key')

    parser.add_argument('--pod_name')
    parser.add_argument('--svc_name')
    parser.add_argument('--app_port')
    parser.add_argument('--svc_port')
    parser.add_argument('--svc_type')
    parser.add_argument('--app_img_uri')
    parser.add_argument('--app_args', nargs='*')
    parser.add_argument('--app_envs', nargs='*')

    args = parser.parse_args()

    if args.model_name:
        gen_args = {
            'is_web_app': False,
            'seldon_namespace': args.namespace,
            'seldon_name': args.model_name,
            'seldon_sa': args.service_account,
            'model_uri': args.model_uri
        }
    else:
        gen_args = {
            'is_web_app': True,
            'namespace': args.namespace,
            'pod_name': args.pod_name,
            'svc_name': args.svc_name,
            'app_port': args.app_port,
            'svc_port': args.svc_port,
            'svc_type': args.svc_type,
            'app_img_uri': args.app_img_uri,
            'app_args': ' '.join(args.app_args),
            'app_envs': ' '.join(args.app_envs)
        }

    with open('svc_creation/resource.yaml.jinja2') as template_f,\
            open('resource.yaml', 'w+') as yaml_f:
        template = Template(template_f.read())

        if args.fmt_args is None:
            gen_yaml(template, gen_args, yaml_f)
        else:
            args_list = expand_dict(' '.join(args.fmt_args))
            for i, args in enumerate(args_list):
                if i != 0:
                    yaml_f.write('---')
                cur_gen_args = fmt_dict(gen_args, args)
                gen_yaml(template, cur_gen_args, yaml_f)
