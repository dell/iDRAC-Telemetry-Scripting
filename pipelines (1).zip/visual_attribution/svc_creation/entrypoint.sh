#!/bin/bash
. /envs/visual_attribution//bin/activate

python3 /visual_attribution/svc_creation/yaml_gen.py "$@"
kubectl delete -f resource.yaml
kubectl apply -f resource.yaml

FMT_DICT=()

while (($#)); do
    case $1 in
        "--namespace")
            shift
            NAMESPACE=$1
            shift
            ;;
        "--model_name")
            shift
            MODEL_NAME=$1
            shift
            ;;
        "--model_uri")
            shift
            MODEL_URI=$1
            shift
            ;;
        "--svc_name")
            shift
            SVC_NAME=$1
            shift
            ;;
        "--svc_type")
            shift
            SVC_TYPE=$1
            shift
            ;;
        "--show_load_balancer")
            shift
            SHOW_LOAD_BALANCER=$1
            shift
            ;;
        "--fmt_args")
            shift
            while [[ $1 != --* ]] && (($#)); do
                FMT_ARGS+=($1)
                shift
            done
            ;;
        *)
            shift
            ;;
    esac
done

if [[ -n "$MODEL_NAME" ]]; then
  ARGS="--namespace $NAMESPACE --model_name $MODEL_NAME --model_uri $MODEL_URI --show_load_balancer $SHOW_LOAD_BALANCER"
else
  ARGS="--namespace $NAMESPACE --svc_name $SVC_NAME --show_load_balancer $SHOW_LOAD_BALANCER"
fi

if [[ -n "$FMT_ARGS" ]]; then
  ARGS=$ARGS" --fmt_args "${FMT_ARGS[*]}
fi

if [[ -n "$SVC_NAME" ]] && [[ $SVC_TYPE == LoadBalancer ]]; then
  echo $ARGS
  python3 /visual_attribution/svc_creation/svc_url.py $ARGS
fi
