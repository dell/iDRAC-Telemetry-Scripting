# Table of Contents
* [Introduction](#Introduction)
* [Preparation](#Preparation)
* [Launch](#Launch)

# Introduction

#### Visual Attribution

Visual attribution is the problem
of identifying object features using its photo.
This problem is very important
as it is often used as part of a solution 
for a wide range of tasks.
Among these tasks can be:

* Making a well-attributed catalog
which will give users the ability
to filter product specifying their characteristics.
* Making recommendations showing similar products.
* Making visual search allowing to find products by images.

In this showcase, we will show what is a visual attribution
solving this problem for women dresses.
At the end of the path, you could upload an image with a dress
and get a prediction for such attributes as length and color.

#### Pipelines

Our solution consists of two pipelines named *serve pipeline* and *seldon pipeline*.
Latter pipeline is used for training and verification and consists of the
following components:

* [Model Training](training)
* [Metrics Logging](tensor_board)
* Serving model with [Seldon](https://docs.seldon.io/projects/seldon-core/en/latest/)
* [Web App](web_app)

Former, *serve pipeline* is used for serving existing model, without training.
Pipeline relies on S3-compatible storage for datasets and model storage.

# Preparation

#### Environment preparation

These pipelines were developed and tested in the following environment:

* VSphere 7.0
* Kubernetes cluster (v1.16) managed by TKG
* Harbor as private registry
* KubeFlow v1.0.2

Kubeflow is already installed with internal S3-compatible storage solution - MinIO.
To allow access to MinIO in your custom KubeFlow namespace (where model will be served),
secret and service account must be created.
Save following YAML as `secret.yaml`:

    ---
    apiVersion: v1
    kind: Secret
    metadata:
      name: s3-secret
      annotations:
        serving.kubeflow.org/s3-endpoint: minio-service.kubeflow:9000
        serving.kubeflow.org/s3-usehttps: "0"
    type: Opaque
    data:
      awsAccessKeyID: bWluaW8=
      awsSecretAccessKey: bWluaW8xMjM=
    ---
    apiVersion: v1
    kind: ServiceAccount
    metadata:
      name: s3sa
    secrets:
    - name: s3-secret

Apply configuration in the desired namespace: `kubectl -n gd-ml apply -f secret.yaml`
*Note: if you changed default MinIO credentials - update secret accordingly*

Pipeline require two buckets created - one for dataset storage and one for trained model storage.
Names could be arbitrary, but good default choice is `dell-ml-datasets` and `dell-ml-models`

#### Data preparation

To train the model you need data. We recommend you to use
[our data](https://storage.googleapis.com/dell-ml-datasets/visual-attribution/data.tar.gz)
which is publicly available.

Upload data to MinIO KubeFlow storage in the dataset bucket, so pipeline could access it.

#### Container preparation

Pipeline relies on custom code packaged in containers for training
and example applications. Thus containers must be built and pushed 
to the registry first.
And any time you made modifications you should build containers
and push them to your registry.
The easiest way to do this is to follow these two steps:
1. Modify the container registry hostname and project
in the [constants file](consts/__init__.py).
2. Build and push containers
by running `python3 docker_push.py` in terminal.

#### Pipeline preparation

To run a pipeline you need to create a manifest
describing a pipeline
and then pass it to kubeflow.
Let us take a closer look at what you need to do:

1.
    Run `python3 pipeline/pipeline_name.py`
    where `pipeline_name` is `serve_pipeline` or `seldon_pipeline`.
    This command will generate for you a manifest
    with `yaml` extension.
2.
    Go to the kubeflow dashboard
    and chose "pipelines" in the menu bar.
    Then click the "Upload pipeline" button
    to upload your manifest
    generated on the previous step.

    ![Pipeline upload](docs/pipeline_upload.jpg)

Now all is ready to run your experiments.


# Launch

1. Choose the pipeline you have uploaded on the previous step.
Once you do it you will the new page showing a graph
which nodes correspond to the pipeline components.
Click "Create run" on this page.

    ![Pipeline launch](docs/pipeline_launch.png)
    
2. Specify name, experiment and pipeline parameters
and click the "Start" button.

3. Click on run you have started on the previous page.
Now you can see how the pipeline is running.
Once one step finished it becomes green and
another step starts.

When step is finished you can click on it and
choose a tab you interested in.
For instance, if you choose [TensorBoard](tensor_board) or [Web App](web_app)
you can open the artifacts tab and follow the link
to open TensorBoard or Web App.

![Pipeline execution](docs/pipeline_launch_2.png)
