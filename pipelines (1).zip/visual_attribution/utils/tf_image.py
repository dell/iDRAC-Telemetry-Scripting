import tensorflow as tf


def tf_pad_img(img):
    img_shape = tf.shape(img)
    target_size = tf.maximum(img_shape[0], img_shape[1])

    u_pad = (target_size - img_shape[0]) // tf.constant(2)
    d_pad = target_size - img_shape[0] - u_pad
    l_pad = (target_size - img_shape[1]) // tf.constant(2)
    r_pad = target_size - img_shape[1] - l_pad

    pad = [[u_pad, d_pad], [l_pad, r_pad], [0, 0]]
    return tf.pad(img, pad, constant_values=255)


def tf_resize_img(img, img_size):
    img = tf_pad_img(img)
    return tf.image.resize(img, img_size)


def tf_process_bin_img(bin_img,
                       aug_fn=None,
                       img_size=None,
                       preprocess_fn=None):
    img = tf.io.decode_image(bin_img, channels=3, dtype=tf.uint8)

    if aug_fn is not None:
        img = tf.py_func(aug_fn, [img], tf.uint8)
    if img_size is not None:
        img = tf_resize_img(img, img_size)

    if preprocess_fn is not None:
        img = tf.cast(img, dtype=tf.float32)
        img = preprocess_fn(img)
    else:
        img = tf.image.convert_image_dtype(img, dtype=tf.uint8)
    img.set_shape(img_size + (3,))

    return img
