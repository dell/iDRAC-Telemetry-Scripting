import os
import tensorflow as tf

from utils.tf_image import tf_process_bin_img


class InputFn:
    def __init__(
        self,
        img_paths,
        labels=None,
        shuffle=False,
        batch_size=32,
        root_path='',
        aug_fn=lambda img: img,
        img_size=(299, 299),
        preprocess_fn=None
    ):
        make_abs_path = lambda img_path: os.path.join(root_path, img_path).encode()
        img_paths = list(map(make_abs_path, img_paths))

        self._img_paths = img_paths
        self._path2label = None if labels is None else dict(zip(img_paths, labels))

        self._shuffle = shuffle
        self._batch_size = batch_size
        self._aug_fn = aug_fn
        self._img_size = img_size
        self._preprocess_fn = preprocess_fn

    def _get_label(self, img_path):
        return self._path2label[img_path]

    def _get_img(self, img_path):
        bin_img = tf.io.read_file(img_path)
        return tf_process_bin_img(bin_img,
                                  aug_fn=self._aug_fn,
                                  img_size=self._img_size,
                                  preprocess_fn=self._preprocess_fn)

    def _get_item(self, img_path):
        label = tf.py_func(self._get_label, [img_path], tf.float32)
        img = self._get_img(img_path)
        return img, label

    def __call__(self):
        dataset = tf.data.Dataset.from_tensor_slices(self._img_paths)

        if self._shuffle:
            dataset_size = len(self._path2label)
            dataset = dataset.shuffle(dataset_size)

        return dataset.map(self._get_item).batch(self._batch_size)


class ServingInputFn:
    def __init__(self,
                 img_size=(299, 299),
                 preprocess_fn=None
                 ):
        self._img_size = img_size
        self._preprocess_fn = preprocess_fn

    def __call__(self):
        bin_imgs = tf.placeholder(shape=[None], dtype=tf.string)
        features = tf_process_bin_img(bin_imgs[0],
                                      img_size=self._img_size,
                                      preprocess_fn=self._preprocess_fn)
        features = tf.expand_dims(features, axis=0)
        return tf.estimator.export.ServingInputReceiver({'input': features}, {'image_bytes': bin_imgs})
