from albumentations import *


class Augmentor:
    def __init__(self):
        noise = OneOf([ISONoise(p=1, intensity=(1, 2)),
                       MotionBlur(blur_limit=32, p=1),
                       GaussianBlur(blur_limit=32, p=1)], p=0.5)
        flip = HorizontalFlip(p=0.5)
        rot = Rotate(limit=5, border_mode=0, value=[255, 255, 255], p=1)
        self._aug = Compose([noise, flip, rot], p=1)

    def __call__(self, img):
        return self._aug(image=img)['image']
