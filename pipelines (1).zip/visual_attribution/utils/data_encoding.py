from sklearn.preprocessing import LabelEncoder


def encode_data(data_frame, target_attr):
    encoder = LabelEncoder()
    encoder.fit(data_frame[target_attr])

    encode_row = lambda x: encoder.transform(x) if x.name == target_attr else x
    data_frame = data_frame.apply(encode_row)

    return data_frame, encoder.classes_.tolist()
