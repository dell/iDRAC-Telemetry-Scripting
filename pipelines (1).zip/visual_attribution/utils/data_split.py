import hashlib
import numpy as np


def in_range(id_hash, low, high):
    return low * 100 <= id_hash % 100 < high * 100


def is_train(item_id, train_size):
    item_id_hash = int(hashlib.md5(item_id.encode('utf-8')).hexdigest(), 16)
    return in_range(item_id_hash, 0, train_size)


def split_train_test(data, id_attr, train_size):
    filter_fn = lambda item_id: is_train(item_id, train_size)
    mask = np.vectorize(filter_fn)(data[id_attr])

    return data[mask], data[~mask]
