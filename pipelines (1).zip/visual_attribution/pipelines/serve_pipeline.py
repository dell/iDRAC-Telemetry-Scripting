import kfp.dsl as dsl
import kfp.compiler as compiler
from kubernetes.client.models import V1Volume, V1EnvVar
from kubernetes.client.models import V1EnvVarSource
from kubernetes.client.models import V1SecretKeySelector

import consts

@dsl.pipeline(
    name='va_serve_pipeline'
)
def pipeline(dataset_uri='s3://dell-ml-datasets/visual-attribution/data.tar.gz',
             model_dir_uri='s3://dell-ml-models/visual-attribution/models/',
             encoding_dir_uri='s3://dell-ml-models/visual-attribution/encodings/',
             metadata_path='metadata.csv',
             id_attr='image_path',
             img_path_attr='image_path',
             target_attr='length color',
             model_name='dress-length-model dress-color-model'):

    ##############################
    # Serve using Seldon TF server
    # Helper image generates several SeldonDeployments
    ##############################
    serving = dsl.ContainerOp(name='serving',
                              image=consts.SVC_CREATION_IMG_URI,
                              arguments=[
                                  '--fmt_args', f'model_name={model_name}',
                                  '--namespace', consts.SELDON_NAMESPACE,
                                  '--service_account', consts.SERVING_S3_SERVICE_ACCOUNT,
                                  '--model_name', '{model_name}',
                                  '--model_uri', f'{model_dir_uri}{{model_name}}',
                                  '--show_load_balancer', '0',
                                  '--app_args', '',
                                  '--app_envs', ''
                              ])
    serving.set_image_pull_policy("Always")

    #########################
    # Sample Web application
    #########################

    # Web application service
    webapp_svc_manifest = { "apiVersion": "v1",
                            "kind": "Service",
                            "metadata": {
                              "name": consts.WEB_APP_SVC_NAME,
                              "namespace": consts.NAMESPACE
                            },
                            "spec": {
                              "type": "LoadBalancer",
                              "selector": {
                                "app": consts.WEB_APP_POD_NAME
                              },
                              "ports": [
                                { "port": consts.WEB_APP_SVC_PORT,
                                  "targetPort": consts.WEB_APP_PORT }
                              ]
                            }
                          }
    webapp_svc = dsl.ResourceOp(
        name='webapp-service',
        k8s_resource=webapp_svc_manifest,
        action='create'
    )
    webapp_svc.after(serving)

    # Web application gateway
    webapp_istio_manifest = { "apiVersion": "networking.istio.io/v1alpha3",
                              "kind": "VirtualService",
                              "metadata": {
                                "name": consts.WEB_APP_SVC_NAME,
                                "namespace": consts.NAMESPACE
                              },
                              "spec": {
                                  "gateways": [ "kubeflow-gateway" ],
                                  "hosts": [ '*' ],
                                  "http": [
                                    { "match": [ { "uri": { "prefix": "/"+consts.WEB_APP_SVC_NAME+"/" }} ],
                                      "rewrite": { "uri": "/" },
                                      "route": [
                                        { "destination": {
                                             "host": consts.WEB_APP_SVC_NAME +
                                             "." + consts.NAMESPACE +
                                             ".svc.cluster.local",
                                             "port": { "number": consts.WEB_APP_SVC_PORT }
                                          }
                                        }
                                      ]
                                    }
                                  ]
                              }
                           }
    webapp_istio = dsl.ResourceOp(
        name='webapp-url',
        k8s_resource=webapp_istio_manifest,
        action='apply',
        attribute_outputs={'link': '[Web application](/' + consts.WEB_APP_SVC_NAME + '/)'}
    )
    webapp_istio.after(webapp_svc)
    webapp_url = webapp_istio.outputs["link"]

    # Link generation for UI
    webapp_meta = dsl.ContainerOp(name='meta',
                              image='/'.join([consts.CONTAINER_REGISTRY,
                                              consts.PROJECT_NAME,
                                              'meta:1.1']),
                              arguments=[
                                  'meta.py',
                                  webapp_url,
                                  '/output.json'
                              ],
                              file_outputs={
                                  'mlpipeline-ui-metadata': '/output.json'
                              })
    webapp_meta.after(webapp_istio)

    # Web application
    webapp_manifest = { "apiVersion": "apps/v1",
                        "kind": "Deployment",
                        "metadata": {
                          "name": consts.WEB_APP_POD_NAME,
                          "namespace": consts.NAMESPACE
                        },
                        "spec": {
                          "selector": {
                            "matchLabels": {
                              "app": consts.WEB_APP_POD_NAME
                            }
                          },
                          "replicas": 1,
                          "template": {
                            "metadata": {
                              "labels": {
                                "app": consts.WEB_APP_POD_NAME
                              }
                            },
                            "spec": {
                              "containers": [
                                {"name": consts.WEB_APP_POD_NAME,
                                 "image": consts.WEB_APP_IMG_URI,
                                 "args": [
                                   '--use_thin_client', '0',
                                   '--web_app_port', f'{consts.WEB_APP_PORT}',
                                   '--serving_uri', f'{consts.SELDON_SERVING_URI}',
                                   '--encoding_dir_uri', f'{encoding_dir_uri}',
                                   '--model_name', f'{model_name}',
                                   '--s3_endpoint', 'http://minio-service.kubeflow:9000/'
                                 ],
                                 "env": [
                                    V1EnvVar('AWS_ACCESS_KEY_ID',
                                             value_from=V1EnvVarSource(
                                                 secret_key_ref=V1SecretKeySelector(
                                                     name=consts.MINIO_SECRET_NAME,
                                                     key='accesskey'
                                                     )
                                                 )
                                            ),
                                    V1EnvVar('AWS_SECRET_ACCESS_KEY',
                                             value_from=V1EnvVarSource(
                                                 secret_key_ref=V1SecretKeySelector(
                                                     name=consts.MINIO_SECRET_NAME,
                                                     key='secretkey'
                                                     )
                                                 )
                                            ),
                                 ],
                                 "ports": [
                                   {"containerPort": consts.WEB_APP_PORT}
                                 ]}]
                            }
                          }
                        }
                      }
    webapp = dsl.ResourceOp(
        name='webapp',
        k8s_resource=webapp_manifest,
        action='create'
    )
    webapp.after(serving)
    webapp.after(webapp_svc)


if __name__ == '__main__':
    compiler.Compiler().compile(pipeline, 'va_serve_pipeline.yaml')
