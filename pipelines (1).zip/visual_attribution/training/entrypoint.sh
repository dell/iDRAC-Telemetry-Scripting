#!/bin/bash

ARGS=""
MODEL_NAME=()

while (($#)); do
    case $1 in
        "--model_name")
            shift
            while [[ $1 != --* ]] && (($#)); do
                MODEL_NAME+=($1)
                shift
            done
            ;;
        "--dataset_creds_json")
            shift
            DATASET_CREDS_JSON=$1
            shift
            ;;
        "--model_creds_json")
            shift
            MODEL_CREDS_JSON=$1
            shift
            ;;
        "--dataset_endpoint")
            shift
            DATASET_ENDPOINT=$1
            shift
            ;;
        "--dataset_access_key_id")
            shift
            DATASET_ACCESS_KEY_ID=$1
            shift
            ;;
        "--dataset_secret_access_key")
            shift
            DATASET_SECRET_ACCESS_KEY=$1
            shift
            ;;
        "--model_endpoint")
            shift
            MODEL_ENDPOINT=$1
            shift
            ;;
        "--model_access_key_id")
            shift
            MODEL_ACCESS_KEY_ID=$1
            shift
            ;;
        "--model_secret_access_key")
            shift
            MODEL_SECRET_ACCESS_KEY=$1
            shift
            ;;
        "--dataset_uri")
            shift
            DATASET_URI=$1
            shift
            ;;
        "--model_dir_uri")
            shift
            MODEL_DIR_URI=$1
            shift
            ;;
        "--encoding_dir_uri")
            shift
            ENCODING_DIR_URI=$1
            shift
            ;;
        "--tb_host")
            shift
            TB_HOST=$1
            shift
            ;;
        *)
            ARGS=$ARGS" "$1
            shift
            ;;
    esac
done

#echo "Host *" >> /root/.ssh/config
#echo "    StrictHostKeyChecking no" >> /root/.ssh/config
#chmod 400 /root/.ssh/config

#mkdir /model_dir
#echo "*  * 	* * * 	root	rsync --inplace -a --exclude 'keras' --exclude 'graph*' --exclude 'model*'  /model_dir/ root@$TB_HOST:/model_dir/" >> /etc/crontab
#service cron restart

if [[ $DATASET_URI == gs://* ]]; then
  echo $DATASET_CREDS_JSON > /creds.json
  gcloud auth activate-service-account --key-file=/creds.json

  gsutil cp $DATASET_URI .
else
  export AWS_ACCESS_KEY_ID=$DATASET_ACCESS_KEY_ID
  export AWS_SECRET_ACCESS_KEY=$DATASET_SECRET_ACCESS_KEY

  aws configure set default.s3.multipart_threshold 10GB
  aws --endpoint-url $DATASET_ENDPOINT s3 cp $DATASET_URI .
fi

mkdir /dataset/
tar xzf *.tar.gz -C /dataset/ --strip-components 1

mkdir /bin_models/
mkdir /encodings/
python3 /visual_attribution/training/training.py $ARGS --model_name ${MODEL_NAME[*]}

if [[ $DATASET_URI == gs://* ]]; then
  echo $MODEL_CREDS_JSON > /creds.json
  gcloud auth activate-service-account --key-file=/creds.json

  for ITEM in ${MODEL_NAME[*]}; do
      gsutil cp "/encodings/"$ITEM".json" $ENCODING_DIR_URI""$ITEM".json"
      gsutil rm -r $MODEL_DIR_URI""$ITEM
      gsutil cp -r "/bin_models/"$ITEM $MODEL_DIR_URI""$ITEM
  done
else
  export AWS_ACCESS_KEY_ID=$MODEL_ACCESS_KEY_ID
  export AWS_SECRET_ACCESS_KEY=$MODEL_SECRET_ACCESS_KEY
  aws configure set default.s3.multipart_threshold 10GB

  for ITEM in ${MODEL_NAME[*]}; do
      aws --endpoint-url $MODEL_ENDPOINT s3 cp "/encodings/"$ITEM".json" $ENCODING_DIR_URI""$ITEM".json"
      aws --endpoint-url $MODEL_ENDPOINT s3 rm --recursive $MODEL_DIR_URI""$ITEM
      aws --endpoint-url $MODEL_ENDPOINT s3 cp --recursive "/bin_models/"$ITEM $MODEL_DIR_URI""$ITEM
  done
fi

sleep 90
