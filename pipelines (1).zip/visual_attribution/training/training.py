import os
import time
import re
import json
import argparse

import numpy as np
import pandas as pd

import tensorflow as tf
from tensorflow.keras.utils import to_categorical, Sequence
from tensorflow.keras.applications.inception_v3 import InceptionV3, preprocess_input
from tensorflow.keras.applications.xception import Xception, preprocess_input
from tensorflow.keras.layers import Input, BatchNormalization, Dropout, Dense, Lambda
from tensorflow.keras.models import Model
from tensorflow.keras.losses import categorical_crossentropy
from tensorflow.keras.metrics import  categorical_accuracy

from utils.data_split import split_train_test
from utils.data_encoding import encode_data
from utils.augs import Augmentor
from utils.input_fns import InputFn, ServingInputFn

STEPS_PER_EPOCH = None
IMG_SIZE = 299, 299
BATCH_SIZE = 32
NUM_EPOCHS = 1
MODEL_PATH_FMT = '/bin_models/{model_name}_epoch:{{epoch_num}}_loss:{{val_loss:.4f}}_acc:{{val_acc:.4f}}'


def prepare_data(metadata_path, id_attr, img_path_attr, target_attr, dir_path, encoding_path):
    metadata = pd.read_csv(metadata_path)
    metadata = metadata[metadata[target_attr].notnull()]
    metadata = metadata[metadata.apply(lambda x: os.path.exists(os.path.join(dir_path, x[img_path_attr])), axis=1)]

    metadata, encoding_dict = encode_data(metadata, target_attr)
    with open(encoding_path, 'w+') as f:
        json.dump(encoding_dict, f)

    train_metadata, test_metadata = split_train_test(metadata, id_attr, 0.8)

    x_train, x_test = train_metadata[img_path_attr].to_numpy(), test_metadata[img_path_attr].to_numpy()
    y_train, y_test = train_metadata[target_attr].to_numpy(), test_metadata[target_attr].to_numpy()
    y_train, y_test = to_categorical(y_train), to_categorical(y_test)

    return x_train, y_train, x_test, y_test, len(encoding_dict)


def get_input_fns(x_train, y_train, x_test, y_test, img_dir_path):
    train_params = {
        'shuffle': True,
        'batch_size': BATCH_SIZE,
        'root_path': img_dir_path,
        'aug_fn': Augmentor(),
        'img_size': IMG_SIZE,
        'preprocess_fn': preprocess_input,
    }

    test_params = {
        'shuffle': False,
        'batch_size': BATCH_SIZE,
        'root_path': img_dir_path,
        'img_size': IMG_SIZE,
        'preprocess_fn': preprocess_input,
    }

    serving_params = {
        'img_size': IMG_SIZE,
        'preprocess_fn': preprocess_input,
    }

    return InputFn(x_train, y_train, **train_params),\
           InputFn(x_test, y_test, **test_params),\
           ServingInputFn(**serving_params)


def get_model(in_dim, num_classes):
    input_img = Input(shape=in_dim, name='input')
    backbone = Xception(include_top=False, input_shape=in_dim, weights='imagenet', pooling='max')(input_img)
    x = Dense(num_classes, activation='softmax', name='final_fc')(backbone)

    return Model(inputs=input_img, outputs=x)


def acc_fn(labels, predictions):
    acc = categorical_accuracy(labels, predictions)
    tf.summary.scalar('accuracy', tf.reduce_mean(acc))
    return acc


def train(model, train_input_fn, eval_input_fn, serving_input_fn, model_path, model_name):
    print(model_name)

    for layer in model.layers[:-1]:
        layer.trainable = False
    model.layers[-1].trainable = True

    optimizer = tf.train.AdamOptimizer(learning_rate=0.001)
    model.compile(optimizer=optimizer, loss=categorical_crossentropy, metrics=[acc_fn])

    global STEPS_PER_EPOCH
    session_config = tf.ConfigProto(device_count={'CPU': 3})
    config = tf.estimator.RunConfig(session_config=session_config,
                                    model_dir='/model_dir/{model_name}'.format(model_name=model_name),
                                    save_checkpoints_steps=STEPS_PER_EPOCH,
                                    save_summary_steps=1,
                                    log_step_count_steps=1)

    estimator = tf.keras.estimator.model_to_estimator(keras_model=model,
                                                      config=config)
    train_spec = tf.estimator.TrainSpec(input_fn=train_input_fn, max_steps=STEPS_PER_EPOCH)
    eval_spec = tf.estimator.EvalSpec(input_fn=eval_input_fn, steps=None)

    start_time = time.time()
    for _ in range(NUM_EPOCHS):
        tf.estimator.train_and_evaluate(estimator, train_spec, eval_spec)
    training_time = (time.time() - start_time) / 60
    print('Run completed in {training_time:.2f} mins'.format(training_time=training_time))

    model_path = model_path.format(epoch_num=1, val_loss=0.0, val_acc=1.0)
    estimator.export_saved_model(model_path, serving_input_fn)


def take_best_model(model_path_fmt):
    model_path_fmt = re.sub('{[^}]*}', '.*', model_path_fmt)
    model_name = os.path.basename(model_path_fmt).split('_', 1)[0]

    def filter_fn(model_path):
        return bool(re.match(model_path_fmt, model_path))

    model_dir_path = os.path.dirname(model_path_fmt)
    model_paths = map(lambda model_path: os.path.join(model_dir_path, model_path), os.listdir(model_dir_path))
    model_paths = list(filter(filter_fn, model_paths))

    model_losses = list(map(lambda model_path: float(re.search('loss:([^_]*)', model_path).group(1)), model_paths))
    best_model_idx = np.argmin(model_losses).item()
    best_model_name = model_paths[best_model_idx]

    os.rename(best_model_name, '/bin_models/{model_name}'.format(model_name=model_name))


def main(model_name, encoding_path, metadata_path,
         id_attr, img_path_attr, target_attr):

    x_train, y_train, x_test, y_test, num_classes = \
        prepare_data(metadata_path, id_attr, img_path_attr, target_attr, BASE_DIR, encoding_path)
    global STEPS_PER_EPOCH
    STEPS_PER_EPOCH = (len(x_train) + BATCH_SIZE - 1) // BATCH_SIZE
    train_input_fn, eval_input_fn, serving_input_fn = get_input_fns(x_train, y_train, x_test, y_test, BASE_DIR)

    in_dim = IMG_SIZE + (3,)
    model_path = MODEL_PATH_FMT.format(model_name=model_name)
    model = get_model(in_dim, num_classes)

    train(model, train_input_fn, eval_input_fn, serving_input_fn, model_path, model_name)
    take_best_model(model_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_name', required=True, nargs='+')
    parser.add_argument('--metadata_path', required=True)
    parser.add_argument('--id_attr', required=True)
    parser.add_argument('--img_path_attr', required=True)
    parser.add_argument('--target_attr', required=True, nargs='+')
    args = parser.parse_args()

    BASE_DIR = '/dataset/'
    metadata_path = os.path.join(BASE_DIR, args.metadata_path)

    for model_name, target_attr in zip(args.model_name, args.target_attr):
        encoding_path = '/encodings/{model_name}.json'.format(model_name=model_name)
        main(model_name, encoding_path, metadata_path,
             args.id_attr, args.img_path_attr, target_attr)
