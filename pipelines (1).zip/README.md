This project is part of Dell EMC Reference Architecture with Grid Dynamics for Open Source Data Science Platforms. 

# Business cases 

To demonstrate how this platform can be leveraged in real life we review few typical problems that our clients has been dealing with on daily basis. There are two cases that can be found as part of our common installation: prediction for marketing (XGBoost) and visual classification (Tensorflow). Those examples are Open Source Software so everyone can use them as starting point for they journey into Machine Learning. 

# Marketing recommendation system

_Stack: XGBoost, Kubeflow Python SDK and Kubeflow pipeline_

_Target domain: Retail, Marketing_ 

In this [example](marketing_showcase) we are building, train and serve model that allow you to create simple prediction for marketing teams in two Jupyter Notebooks. We are proposing solution for problem of finding optimal pricing for goods and products. 

[Pricing decisions](https://blog.griddynamics.com/predictive-analytics-for-promotion-and-price-optimization/) are critically important for any business, as pricing is directly linked to consumer demand and company profits. Even a slightly suboptimal decision-making process inevitably leads to tangible losses, and major mistakes can have grave consequences.

Although the fundamentals of price optimization are well understood, our experience with dozens of leading retailers clearly indicates that retail practitioners are struggling with certain pricing decisions. Even ones that presumably make the right pricing decisions are often uncertain if they have unharvested profits or avoidable losses due to suboptimal pricing, and the lack of tools and techniques to measure it quantitatively.

# “More like this” and visual search engines 

_Stack: Tensorflow, Keras, Kubeflow Python SDK and Kubeflow pipeline_

_Target domain: Retail, Search Engines, Recommendation Systems_ 

This [example](visual_attribution) covers more advance use case of visual classification. Final model should recognize your uploaded photo of dress and display two attributes as length and color.  We are using pre-train general purpose model and big dataset of women dresses to train two models to recognize color in one case and length of dress in another. To train this model it uses Tensorflow framework and GPU powered machines to achieve acceptable accuracy. In this case we are using serving capability to deploy this model as API service. For convenience, we are deploying web-based UI to allow user upload picture of women dress and receive appropriate descriptions in more user-friendly manner.  

There few similar business cases to use visual classification. As an example: 

- [Expanding product discovery with ML-powered image similarity search](https://blog.griddynamics.com/expanding-product-search-with-image-similarity/). Here, you can see how the model can pick up the main characteristics of the sample dress and find similar-looking short striped dresses from the catalog. This feature can also be termed “visual recommendation” or “show me more like this”.
- [A visual search for dinnerware patterns with Replacements.com](https://blog.griddynamics.com/a_visual_search_for_dinnerware_patterns/). Finding a matching plate or mug is a challenging process for the customer. Often, they can’t remember the name of their pattern or the company that produced it. Grid Dynamics engaged with Replacements.com to design and train a set of deep learning models and develop a set of visual search APIs capable of matching patterns based on a photo uploaded by a customer.
- [Identifying screws, a practical case study for visual search](https://blog.griddynamics.com/identifying-screws-a-practical-use-case-study-for-visual-search/). Screws are visually very similar to each other, and therefore hard to distinguish. Traditional approaches to matching these kinds of parts are all frustrating and slow, and usually involve visually comparing your item to a huge catalog of choices. Wouldn’t it be nice if you could just point your smartphone to the screw that you need, and have it easily show up online?
