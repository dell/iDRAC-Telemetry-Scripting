
Table of Contents
=================
* [Prepare data](#Prepare-data)
* [Prepare Docker images](#Prepare-Docker-images)
* [Running the Pipeline](#Running-the-Pipeline)
    * [Pipeline Structure](#Pipeline-Structure)
    * [Compile the Pipeline](#Compile-the-Pipeline)
    * [Run the Pipeline](#Run-the-Pipeline)
* [Testing](#Testing)
    * [Check logs](#Check-logs)
    * [Test API](#Test-API)

# Promo optimization
Price optimization is one of the most important features that directly affect enterprise profitability and efficiency. 
We consider one of the features "Discount promo optimization".
We show how build simple model that can help to define optimal discount for next day. This model build base on previous 
history transactions and help predict quantity considering promotion price with discount from range of possible discounts, default from 0%(w/o promo) to 50% with step 5%.
Optimal discount has maximum profit.

## Prepare environment

These pipelines were developed and tested in the following environment:

* VSphere 7.0
* Kubernetes cluster (v1.16) managed by TKG
* Harbor as private registry
* KubeFlow v1.0.2

Kubeflow is already installed with internal S3-compatible storage solution - MinIO.
To allow access to MinIO in your custom KubeFlow namespace (where model will be served),
secret and service account must be created.
Save following YAML as `secret.yaml`:

    ---
    apiVersion: v1
    kind: Secret
    metadata:
      name: s3-secret
      annotations:
        serving.kubeflow.org/s3-endpoint: minio-service.kubeflow:9000
        serving.kubeflow.org/s3-usehttps: "0"
    type: Opaque
    data:
      awsAccessKeyID: bWluaW8=
      awsSecretAccessKey: bWluaW8xMjM=
    ---
    apiVersion: v1
    kind: ServiceAccount
    metadata:
      name: s3sa
    secrets:
    - name: s3-secret

Apply configuration in the desired namespace: `kubectl -n gd-ml apply -f secret.yaml`
*Note: if you changed default MinIO credentials - update secret accordingly*

Pipeline require two buckets created - one for dataset storage and one for trained model storage.
Names could be arbitrary, but good default choice is `dell-ml-datasets` and `dell-ml-models`

## Prepare data

Upload dataset and config file to MinIO bucket.
We recommend to use our data:

* [config.json](https://storage.googleapis.com/dell-ml-datasets/promotion-planning/config.json)
* [dataset.zip](https://storage.googleapis.com/dell-ml-datasets/promotion-planning/dataset.zip)


## Prepare Docker images

Pipeline relies on custom code packaged in containers for training
and example applications. Thus containers must be built and pushed 
to the registry first.
And any time you made modifications you should build containers
and push them to your registry.
The easiest way to do this is to follow these two steps:
1. Modify the container registry hostname and project
in the [constants file](consts/__init__.py).
2. Build and push containers
by running `python3 docker_push.py` in terminal.

### Intel® Data Analytics Acceleration Library (Intel® DAAL)

Default training image is using Intel® DAAL optimized XGBoost library.
To be able to run the model on the out-of-box Seldon installation, provided XGBoost image must be upgraded to version XGBoost 1.0.1
We provide [Dockerfile](xgboost/Dockerfile) for convenience.
After image is built and pushed into the registry, we need to tell Seldon to use it.
For this, edit ```seldon-config``` ConfigMap:
```bash
kubectl -n kubeflow edit configmap seldon-config
```
Find configuration for ```XGBOOST_SERVER.rest``` in ```data.predictor_servers``` and update keys ```defaultImageVersion``` and ```iamge```
correspondingly to the image you pushed to the registry.

Example:
```json
"XGBOOST_SERVER": {
  "rest": {
    "defaultImageVersion": "0.2-1.0.1",
    "image": "172.17.11.66/gd/seldonio/xgboostserver_rest"
  }
}
``` 

## Running the Pipeline
#### Pipeline Structure
1) [Train model](./training)
2) Serve model (Seldon XGBoost server)
3) [Api](./web_app)

#### Compile the Pipeline
```bash 
python pipeline/seldon_pipeline.py
```
After execution ```marketing_pipeline.tar.gz``` will be generated. This pipeline have to uploaded to Kubeflow UI.![Kubeflow UI](./img/pipelines.png "Kubeflow UI")

#### Run the Pipeline

After clicking on the newly created pipeline, you should be presented with an overview of the pipeline graph.
When you're ready, select the ```Create Run``` button to launch the pipeline.

![Pipeline](./img/run_pipeline.png "Pipeline")

Fill out the information required for the run, and press ```Start``` when you are ready.


## Testing
#### Check logs
After clicking on the newly created Run, you should see the pipeline run through the ```training```, ```serving```, and ```web-app``` components. Click on any component to see its logs.
When the pipeline is complete, look at the logs for the ```web-app``` component to find the API IP address.

![Logs](./img/logs.png "Logs")

#### Test API
Test API with param ```sku_id``` through curl: 
```bash
curl --location --request POST 'http://172.29.146.13:9000/predict' \
--header 'Content-Type: application/json' \
--data-raw '{
    "sku_id": 396197
}'
``` 
response:
``` 
{
    "opt_discount": 0.0,
    "opt_profit": 163.87568613891563,
    "opt_quantity": 3.0163018703460693
}
``` 
or postman:
![Postman](./img/postman.png "postman")
