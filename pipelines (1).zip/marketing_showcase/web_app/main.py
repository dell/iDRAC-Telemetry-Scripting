import argparse
import json
import os
import requests
import pandas as pd
import numpy as np

from flask import Flask, request, jsonify, abort
from flask_cors import CORS

LOCAL_DATA_DIR = '/dataset/'
REQUEST_HEADERS = {'Content-type': 'application/json'}

app = Flask(__name__)
CORS(app)


def decode_response(response):
    prediction = json.loads(response.text)['data']['tensor']['values'][0]
    return prediction


def call_serving(body):
    global serving_uri

    response = requests.post(serving_uri, data=body, headers=REQUEST_HEADERS)
    return decode_response(response)


def is_valid(data):
    return len(data) == 1


def fetch_test_data(sku_id):
    global config

    predict_day = config['filter']['end'] + 1
    ind = (df['sku_id'] == sku_id) & (df['nday'] == predict_day)
    keep_columns = [column for column, is_trainable in config['features'].items() if is_trainable == 1]

    return (df.loc[ind, keep_columns]
             .drop(['prod_id', 'sku_id'], axis=1, errors='ignore')
             .round(10)
             .astype(np.float32))


@app.route('/predict', methods=['POST'])
def get_prediction():
    sku_id = int(request.get_json()['sku_id'])
    data = fetch_test_data(sku_id)
    if not is_valid(data):
        abort(400)

    data = data.iloc[0].copy()
    df_disc = pd.DataFrame(data=np.arange(0, 0.55, 0.05), columns=['discount'])
    df_opt_dicount = (
        data.to_frame().T.assign(key=1)
            .merge(df_disc.assign(key=1), on="key")
            .drop("key", axis=1)
    )
    df_opt_dicount['promo_price'] = (1 - df_opt_dicount['discount']) * df_opt_dicount['list_price']
    df_opt_dicount['ratio_promo_price_to_list_price'] = df_opt_dicount['promo_price'] / df_opt_dicount['list_price']
    df_opt_dicount['ratio_promo_price_to_purchase_price'] = df_opt_dicount['promo_price'] / df_opt_dicount['purchase_price']
    df_opt_dicount['quantity_pred'] = df_opt_dicount.apply(lambda x: call_serving(get_request_body(x)), axis=1)
    df_opt_dicount['profit'] = df_opt_dicount['quantity_pred'] * (df_opt_dicount['promo_price'] - df_opt_dicount['purchase_price'])

    series_opt = df_opt_dicount.sort_values('profit',  ascending=False).iloc[0]
    return jsonify({'opt_discount': series_opt['discount'],
                    'opt_quantity': series_opt['quantity_pred'],
                    'opt_profit': series_opt['profit']})


def get_request_body(data):
    tensor = {'shape': [1, data.shape[0]], 'values': data.tolist(), 'features': data.index.tolist()}
    body = json.dumps({'data': {'tensor': tensor}})
    return body


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--web_app_port', default='9000')
    parser.add_argument('--serving_uri', required=True)
    args = parser.parse_args()

    serving_uri = args.serving_uri
    app_port = args.web_app_port
    config_path = os.path.join(LOCAL_DATA_DIR, 'config.json')
    dataset_path = os.path.join(LOCAL_DATA_DIR, 'dataset.csv')

    df = pd.read_csv(dataset_path)
    with open(config_path, 'r') as fc:
        config = json.load(fc)

    app.run(host='0.0.0.0', port=app_port)
