#!/bin/bash
. /envs/marketing-showcase/bin/activate

ARGS=""


while (($#)); do
    case $1 in
        "--dataset_endpoint")
            shift
            DATASET_ENDPOINT=$1
            shift
            ;;
        "--dataset_uri")
            shift
            DATASET_URI=$1
            shift
            ;;
        "--config_uri")
            shift
            CONFIG_URI=$1
            shift
            ;;
        *)
            ARGS=$ARGS" "$1
            shift
            ;;
    esac
done

echo $ARGS

aws configure set default.s3.multipart_threshold 10GB
aws --endpoint-url $DATASET_ENDPOINT s3 cp $DATASET_URI .
aws --endpoint-url $DATASET_ENDPOINT s3 cp $CONFIG_URI .

mkdir /dataset/
unzip -qq *.zip -d /dataset/
mv "config.json" "/dataset/config.json"

python3 /marketing-showcase/web_app/main.py $ARGS
