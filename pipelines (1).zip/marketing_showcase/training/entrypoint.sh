#!/bin/bash

ARGS=""

curl google.com

while (($#)); do
    case $1 in
        "--dataset_endpoint")
            shift
            DATASET_ENDPOINT=$1
            shift
            ;;
        "--dataset_access_key_id")
            shift
            DATASET_ACCESS_KEY_ID=$1
            shift
            ;;
        "--dataset_secret_access_key")
            shift
            DATASET_SECRET_ACCESS_KEY=$1
            shift
            ;;
        "--model_endpoint")
            shift
            MODEL_ENDPOINT=$1
            shift
            ;;
        "--model_access_key_id")
            shift
            MODEL_ACCESS_KEY_ID=$1
            shift
            ;;
        "--model_secret_access_key")
            shift
            MODEL_SECRET_ACCESS_KEY=$1
            shift
            ;;
        "--dataset_uri")
            shift
            DATASET_URI=$1
            shift
            ;;
        "--model_uri")
            shift
            MODEL_URI=$1
            shift
            ;;
        "--config_uri")
            shift
            CONFIG_URI=$1
            shift
            ;;
        *)
            ARGS=$ARGS" "$1
            shift
            ;;
    esac
done

echo $ARGS

export AWS_ACCESS_KEY_ID=$DATASET_ACCESS_KEY_ID
export AWS_SECRET_ACCESS_KEY=$DATASET_SECRET_ACCESS_KEY

aws configure set default.s3.multipart_threshold 10GB
aws --endpoint-url $DATASET_ENDPOINT s3 cp $DATASET_URI .
aws --endpoint-url $DATASET_ENDPOINT s3 cp $CONFIG_URI .

mkdir /dataset/
unzip -qq *.zip -d /dataset/
mv config.json "/dataset/config.json"

python3 /marketing-showcase/training/training.py $ARGS

export AWS_ACCESS_KEY_ID=$MODEL_ACCESS_KEY_ID
export AWS_SECRET_ACCESS_KEY=$MODEL_SECRET_ACCESS_KEY

aws --endpoint-url $MODEL_ENDPOINT s3 rm  $MODEL_URI
aws --endpoint-url $MODEL_ENDPOINT s3 cp  "/bin_models/model.bst" $MODEL_URI

sleep 90
