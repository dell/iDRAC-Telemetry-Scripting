import os
import json
import logging
import pickle

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import r2_score
from sklearn.model_selection import cross_val_predict


DATA_DIR = '/dataset/'
MODEL_DIR = '/bin_models/'
logging.basicConfig(format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


class R2OutliersError(object):
    def __init__(self, masks, mask_detector):
        self.masks = masks
        self.mask_detector = mask_detector

    def r2(self, observ, pred, mask_id):
        if mask_id is None:
            score = r2_score(observ, pred)
            logger.info("Validated with score = {}".format(score))
            return score
        condition = ~(self.masks[mask_id])
        score = r2_score(observ[condition], pred[condition])
        print("Validated with score = {}".format(score))
        return score

    def eval_error(self, preds, dtrain):
        labels = dtrain.get_label()
        err = 1 - self.r2(labels, preds, self.mask_detector(dtrain))
        print("R2 = {}".format(1 - err))
        return 'r2_inverse', err


def baseline_predict(x, y, metric):
    base_estimator = xgb.XGBRegressor(outliers_template=None, min_child_weight=2, objective=metric)
    return cross_val_predict(estimator=base_estimator, X=x, y=y, cv=5)


def baseline_outliers_template(X, Y, metric, out_thr):
    bp = baseline_predict(X, Y, metric)
    return np.absolute(np.array(Y) - bp) > out_thr



def train(df,
          features_config,
          filter_config,
          model_config,
          label,
          seed=0):
    keep_columns = [column for column, is_trainable in features_config.items() if is_trainable == 1]
    y = df[label]
    X = (df[keep_columns]
         .drop(['prod_id', 'sku_id'], axis=1, errors='ignore')
         .round(10)
         .astype(np.float32))

    dates = df['nday']
    model_config['n_estimators'] = 1000
    start = int(filter_config.get('start', 0))
    end = int(filter_config.get('end', 0))
    validation_split_size = 0.2
    filter_window = (end - start)
    split_day = start + int(filter_window * (1 - validation_split_size))

    train_start, train_end = start, split_day
    val_start, val_end = split_day, end
    train_range = range(train_start, train_end + 1)
    val_range = range(val_start, val_end + 1)

    train_indices = dates[dates.isin(train_range)].index
    val_indices = dates[dates.isin(val_range)].index

    X_tr = X.loc[train_indices, :]
    y_tr = y.loc[train_indices]

    X_val = X.loc[val_indices, :]
    y_val = y.loc[val_indices]

    def mask_detector(dm):
        if len(dm.get_label()) == len(y_tr):
            return 0
        if len(dm.get_label()) == len(y_val):
            return 1

        return -1

    o_tr_mask = baseline_outliers_template(X_tr, y_tr, "reg:linear", 80)
    o_val_mask = baseline_outliers_template(X_val, y_val, "reg:linear", 80)

    r2_outliers_error = R2OutliersError([o_tr_mask, o_val_mask], mask_detector)
    model = xgb.XGBRegressor(**model_config,
                             objective='reg:squarederror',
                             random_state=seed,
                             n_jobs=-1)
    model.fit(X_tr, y_tr,
              eval_set=[(X_val, y_val)],
              eval_metric=r2_outliers_error.eval_error,
              early_stopping_rounds=20,
              verbose=True)
    model_config['n_estimators'] = model.best_iteration + 1

    model = xgb.XGBRegressor(**model_config,
                             objective='reg:squarederror',
                             random_state=seed,
                             n_jobs=-1)

    model_range = range(start, end + 1)
    indices = dates[dates.isin(model_range)].index
    X = X.loc[indices, :]
    y = y.loc[indices]

    model.fit(X, y)
    return model


def save_model(model):
    os.makedirs(MODEL_DIR, exist_ok=True)
    model_file = os.path.join(MODEL_DIR, 'model.bst')
    model.save_model(model_file)


def main():
    dataset_path = os.path.join(DATA_DIR,  'dataset.csv')
    config_path = os.path.join(DATA_DIR, 'config.json')
    label = 'quantity'

    ds = pd.read_csv(dataset_path)
    with open(config_path, 'r') as fc:
        config = json.load(fc)

    model = train(ds, config['features'], config['filter'], config['model'], label=label)
    save_model(model)


if __name__ == '__main__':
    main()
