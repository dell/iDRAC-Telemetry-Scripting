import kfp.dsl as dsl
import kfp.compiler as compiler
from kubernetes.client.models import V1EnvVar
from kubernetes.client.models import V1EnvVarSource
from kubernetes.client.models import V1SecretKeySelector

import consts


@dsl.pipeline(name='marketing_pipeline')
def pipeline(
        dataset_uri='s3://dell-ml-datasets/promotion-planning/dataset.zip',
        config_uri='s3://dell-ml-datasets/promotion-planning/config.json',
        model_uri='s3://dell-ml-models/model.bst'
):

    ################
    # Train model
    # Using XGBoost
    ################
    training = dsl.ContainerOp(
        name='training',
        image=consts.TRAINING_IMG_URI,
        arguments=[
            '--dataset_uri', dataset_uri,
            '--config_uri', config_uri,
            '--model_uri', model_uri
        ],
        container_kwargs={
            'env': [
                V1EnvVar('DATASET_ENDPOINT', 'http://minio-service.kubeflow:9000/'),
                V1EnvVar('MODEL_ENDPOINT', 'http://minio-service.kubeflow:9000/'),
                V1EnvVar('DATASET_ACCESS_KEY_ID',
                         value_from=V1EnvVarSource(
                             secret_key_ref=V1SecretKeySelector(
                                 name=consts.MINIO_SECRET_NAME,
                                 key='accesskey'
                                 )
                             )
                        ),
                V1EnvVar('DATASET_SECRET_ACCESS_KEY',
                         value_from=V1EnvVarSource(
                             secret_key_ref=V1SecretKeySelector(
                                 name=consts.MINIO_SECRET_NAME,
                                 key='secretkey'
                                 )
                             )
                        ),
                V1EnvVar('MODEL_ACCESS_KEY_ID',
                         value_from=V1EnvVarSource(
                             secret_key_ref=V1SecretKeySelector(
                                 name=consts.MINIO_SECRET_NAME,
                                 key='accesskey'
                                 )
                             )
                        ),
                V1EnvVar('MODEL_SECRET_ACCESS_KEY',
                         value_from=V1EnvVarSource(
                             secret_key_ref=V1SecretKeySelector(
                                 name=consts.MINIO_SECRET_NAME,
                                 key='secretkey'
                                 )
                             )
                        ),
            ]
        },
    )
    training.set_image_pull_policy('Always')
    training.set_cpu_request('3')
    training.set_memory_limit('16G')

    #############################
    # Serve model
    # Using Seldon XGBoost server
    #############################
    serving_manifest = {
        "apiVersion": "machinelearning.seldon.io/v1",
        "kind": "SeldonDeployment",
        "metadata": {
          "name": consts.SERVING_SELDON_MODEL,
          "namespace": consts.SERVING_SELDON_NAMESPACE
        },
        "spec": {
          "name": consts.SERVING_SELDON_MODEL,
          "predictors": [
            { "graph": {
                "children": [],
                "implementation": "XGBOOST_SERVER",
                "modelUri": model_uri,
                "serviceAccountName": consts.SERVING_S3_SERVICE_ACCOUNT,
                "name": "model"
              },
              "name": "default",
              "replicas": 1,
              "svcOrchSpec": {
                "env": [
                  { "name": "SELDON_LOG_LEVEL", "value": "DEBUG" }
                ]
              }
            }
          ]
        }
    }
    serving = dsl.ResourceOp(
        name='seldon-serving',
        k8s_resource=serving_manifest,
        action='apply'
    )
    serving.after(training)

    #################
    # Sample REST API
    #################

    # Kubernetes Service
    webapp_svc_manifest = {
        "apiVersion": "v1",
        "kind": "Service",
        "metadata": {
            "name": consts.WEB_APP_SVC_NAME,
            "namespace": consts.NAMESPACE
        },
        "spec": {
            "type": "LoadBalancer",
            "selector": {"app": consts.WEB_APP_POD_NAME},
            "ports": [
                {
                    "port": consts.WEB_APP_SVC_PORT,
                    "targetPort": consts.WEB_APP_PORT
                }
            ]
        }
    }
    webapp_svc = dsl.ResourceOp(
        name='rest-service',
        k8s_resource=webapp_svc_manifest,
        action='apply'
    )
    webapp_svc.after(training)

    # Istio VirtualService
    webapp_istio_manifest = {
        "apiVersion": "networking.istio.io/v1alpha3",
        "kind": "VirtualService",
        "metadata": {
            "name": consts.WEB_APP_SVC_NAME,
            "namespace": consts.NAMESPACE
        },
        "spec": {
            "gateways": ["kubeflow-gateway"],
            "hosts": ['*'],
            "http": [
                {
                    "match": [{"uri": {"prefix": "/"+consts.WEB_APP_SVC_NAME+"/"}}],
                    "rewrite": {"uri": "/"},
                    "route": [
                        {
                            "destination": {
                                "host": consts.WEB_APP_SVC_NAME + "." +
                                consts.NAMESPACE + ".svc.cluster.local",
                                "port": {"number": consts.WEB_APP_SVC_PORT}
                            }
                        }
                    ]
                }
            ]
        }
    }
    webapp_istio = dsl.ResourceOp(
        name='rest-url',
        k8s_resource=webapp_istio_manifest,
        action='apply',
        attribute_outputs={'url': '/' + consts.WEB_APP_SVC_NAME + '/predict'}
    )
    webapp_istio.after(webapp_svc)

    # REST API
    webapp_manifest = {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {
            "name": consts.WEB_APP_POD_NAME,
            "namespace": consts.NAMESPACE
        },
        "spec": {
            "selector": {"matchLabels": {"app": consts.WEB_APP_POD_NAME}},
            "replicas": 1,
            "template": {
                "metadata": {"labels": {"app": consts.WEB_APP_POD_NAME}},
                "spec": {
                    "containers": [
                        {
                            "name": consts.WEB_APP_POD_NAME,
                            "image": consts.WEB_APP_IMG_URI,
                            "args": [
                                '--web_app_port', f'{consts.WEB_APP_PORT}',
                                '--serving_uri', f'{consts.SERVING_SELDON_URI}',
                                '--dataset_uri', f'{dataset_uri}',
                                '--config_uri', f'{config_uri}',
                                '--dataset_endpoint', 'http://minio-service.kubeflow:9000/'
                            ],
                            "env": [
                                V1EnvVar('AWS_ACCESS_KEY_ID',
                                         value_from=V1EnvVarSource(
                                             secret_key_ref=V1SecretKeySelector(
                                                 name=consts.MINIO_SECRET_NAME,
                                                 key='accesskey'
                                                 )
                                             )
                                        ),
                                V1EnvVar('AWS_SECRET_ACCESS_KEY',
                                         value_from=V1EnvVarSource(
                                             secret_key_ref=V1SecretKeySelector(
                                                 name=consts.MINIO_SECRET_NAME,
                                                 key='secretkey'
                                                 )
                                             )
                                        ),
                            ],
                            "ports": [{"containerPort": consts.WEB_APP_PORT}]
                        }
                    ]
                }
            }
        }
    }
    webapp = dsl.ResourceOp(
        name='rest-app',
        k8s_resource=webapp_manifest,
        action='apply'
    )
    webapp.after(serving)
    webapp.after(webapp_istio)


if __name__ == '__main__':
    compiler.Compiler().compile(pipeline, 'marketing_seldon_pipeline.yaml')
